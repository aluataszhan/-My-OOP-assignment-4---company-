package kz.aitu.oop.practice.assignment4;

import kz.aitu.oop.practice.assignment4.data.Connect;
import kz.aitu.oop.practice.assignment4.entities.Department;
import kz.aitu.oop.practice.assignment4.repositories.DepartmentRepo;
import kz.aitu.oop.practice.assignment4.repositories.EmpRepo;
import kz.aitu.oop.practice.assignment4.repositories.PostRepo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException {
        DepartmentRepo repo = new DepartmentRepo();
        repo.fill();
        System.out.println(repo.getAllObjects().get(0).toString());//here i print information about department

        EmpRepo re = new EmpRepo();
        re.fill();
        System.out.println(re.getAllObjects().get(0).toString());//here i print information about employee

        Department department = new Department("System administration" , "A system administration is a department which is responsible for the upkeep, configuration, and reliable operation of computer systems; especially multi-user computers, such as servers.");
        department.insert();
        //here i add a new row to my table in sql by writing this code

        PostRepo pr = new PostRepo();
        pr.fill();
        System.out.println(pr.getAllObjects().get(1).toString());//here i print information from post table

        ResultSet Post = Connect.getStatement().executeQuery("select sum(salary) from post") ;
    }


}
