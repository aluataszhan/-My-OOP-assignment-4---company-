package kz.aitu.oop.practice.assignment4.repositories;

import kz.aitu.oop.practice.assignment4.entities.Department;
import kz.aitu.oop.practice.assignment4.entities.Post;

import java.sql.SQLException;
import java.util.List;
//"T" which in the code below  is a generic class or interface that is parameterized over types . We call this generic type
public interface Repositories<T> {
    boolean createObjects(T object);

    T getObjects(int id);

    List<T> getAllObjects();

    void fill() throws SQLException;
}
