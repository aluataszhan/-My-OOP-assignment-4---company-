package kz.aitu.oop.practice.assignment4;


import java.util.Scanner;

public class MyApplication {
    /*
    private final DepartmentController controller;
    private final Scanner scanner;


    public MyApplication(DepartmentController controller, Scanner scanner, Scanner scanner1) {
        this.controller = controller;
        this.scanner = scanner1;
        scanner = new Scanner(System.in);
    }
    public void start() {


        }
    }
    */
}